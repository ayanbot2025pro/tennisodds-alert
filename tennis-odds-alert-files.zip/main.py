import os
import requests
import time
from dotenv import load_dotenv
import telegram

load_dotenv()

API_KEY = os.getenv("ODDS_API_KEY")
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

bot = telegram.Bot(token=TELEGRAM_TOKEN)

def fetch_odds():
    url = f"https://api.the-odds-api.com/v4/sports/tennis/odds/?apiKey={API_KEY}&regions=eu&markets=h2h"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        return []

def check_and_alert():
    matches = fetch_odds()
    for match in matches:
        teams = match.get("teams", [])
        sites = match.get("bookmakers", [])
        for site in sites:
            for outcome in site.get("markets", [])[0].get("outcomes", []):
                if outcome.get("price", 0) >= 2.5:
                    message = f"Odds Alert!\nMatch: {' vs '.join(teams)}\nPlayer: {outcome.get('name')}\nOdds: {outcome.get('price')}"
                    bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=message)
                    time.sleep(1)

if __name__ == "__main__":
    while True:
        check_and_alert()
        time.sleep(60)
